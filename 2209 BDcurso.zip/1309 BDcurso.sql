create database aula1309;
use aula1309;

create table Curso(
id_Curso int primary key auto_increment,
nome Varchar(80) not null,
periodo char,
duracao int);

create table disciplina(
id_disciplina int primary key auto_increment,
nome Varchar(80) not null,
professor Varchar(80),
curso int,
foreign key (Curso) references Curso(id_Curso));

insert into Curso values (null, 'tecnico em administracao', "t",  3);
insert into Curso values (null, 'tecnico em desemvolvimento de sistemas', "m", 6);

insert into disciplina values (null,'aplicativos informatizados', 'Celso', 1); 
insert into disciplina values (null, 'programacao web', 'danilo', 2);
insert into disciplina values (null, 'desenvolvimento de sistemas', 'Aquiles', 2);

desc disciplina;

select * from disciplina;
select * from Curso;

select * from curso where duracao <= 3;
select * from disciplina where professor = 'Aquiles';
select * from disciplina order by nome;

select d,nome, d.professor, c.nome from disciplina as d 
