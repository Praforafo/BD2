create database sapataria;

use sapataria;

create table funcionario(
idFuncionario int primary key not null auto_increment,
nome varchar(50),
idade int,
cargo varchar(15));

create table comprador(
idcomprador int primary key auto_increment,

