create database sapataria;

use sapataria;

create table funcionario(
idfuncionario int primary key not null auto_increment,
nome varchar(50),
idade int,
cargo varchar(15),
salario double);

create table comprador(
idcomprador int primary key auto_increment,
CPF varchar(14) not null,
nome varchar(50),
cidade varchar(45),
limitecredito double,
vendedorFK int,
foreign key (vendedorFK) references funcionario(idFuncionario));

create table produto(
idproduto int primary key auto_increment,
nomeproduto varchar(50),
marca varchar(50),
preco double,
compradorFK int,
funcionarioFK int,
foreign key (funcionarioFK) references funcionario(idFuncionario),
foreign key (compradorFK) references comprador(idcomprador));